const express = require('express');
const router = express.Router();
const path = require('path');

// Serve the API tester interface
router.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '../public/api-tester/index.html'));
});

module.exports = router;
