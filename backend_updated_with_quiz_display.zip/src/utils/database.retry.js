const logger = require('../utils/logger');

/**
 * Utility to create a database connection with retry mechanism
 * @param {Function} connectDB - The database connection function
 * @param {Number} maxRetries - Maximum number of retry attempts
 * @param {Number} retryDelay - Delay between retries in milliseconds
 * @returns {Promise} - Resolves when connected or rejects after max retries
 */
const connectWithRetry = async (connectDB, maxRetries = 5, retryDelay = 5000) => {
  let retries = 0;
  
  while (retries < maxRetries) {
    try {
      logger.info(`Attempting database connection (attempt ${retries + 1}/${maxRetries})...`);
      await connectDB();
      logger.info('Database connection established successfully');
      return;
    } catch (error) {
      retries++;
      logger.error(`Database connection failed (attempt ${retries}/${maxRetries}): ${error.message}`);
      
      if (retries >= maxRetries) {
        logger.error('Maximum connection retry attempts reached. Giving up.');
        throw new Error('Failed to connect to the database after multiple attempts');
      }
      
      logger.info(`Retrying in ${retryDelay / 1000} seconds...`);
      await new Promise(resolve => setTimeout(resolve, retryDelay));
    }
  }
};

module.exports = {
  connectWithRetry
};
